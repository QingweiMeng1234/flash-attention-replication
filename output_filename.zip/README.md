## Set up environment
We recommend you to set up a conda environment for packages used in this homework.
```
conda create -n 2590-hw2 python=3.8
conda activate 2590-hw2
pip install -r requirements.txt
```
